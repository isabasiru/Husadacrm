'use client';

import { useState, useEffect, useRef } from 'react';
import { MessageBubble } from './MessageBubble';
import { useSocket } from '@/hooks/use-socket';

interface Contact {
  id: string;
  fullName: string | null;
  whatsappNumber: string;
}

interface ChatWindowProps {
  contact: Contact | null;
}

export function ChatWindow({ contact }: ChatWindowProps) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isNote, setIsNote] = useState(false);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const { joinConversation, onNewMessage } = useSocket();

  useEffect(() => {
    if (!contact) return;

    // Fetch initial messages (the backend returns messages for the active conversation)
    fetch(`/api/contacts/${contact.id}/messages`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setMessages(data);
          // Assuming the first message has the conversationId, we join that room
          if (data.length > 0) {
            joinConversation(data[0].conversationId);
          }
        }
      });

    return () => {
      // Need a way to leave if we knew the conversationId.
      // For simplicity, we can emit leave in a cleanup if we stored conversationId
    };
  }, [contact, joinConversation]);

  // Listen for new messages via socket
  useEffect(() => {
    const cleanup = onNewMessage((data) => {
      // data: { conversationId, message, contact }
      if (contact && data.contact?.id === contact.id) {
        // Skip OUTBOUND messages — sender already added them optimistically via handleSend
        if (data.message?.direction === 'OUTBOUND') return;

        setMessages(prev => {
          // Prevent duplicates
          if (prev.some(m => m.id === data.message.id)) return prev;
          return [...prev, data.message];
        });
      }
    });

    return cleanup;
  }, [contact, onNewMessage]);

  // Auto scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !contact) return;

    const content = input;
    const type = isNote ? 'NOTE' : 'TEXT';

    // Optimistic: add message immediately before API call
    const tempId = `temp-${Date.now()}`;
    const optimisticMsg = {
      id: tempId,
      content,
      direction: 'OUTBOUND' as const,
      type: isNote ? 'INTERNAL_NOTE' : 'TEXT',
      isInternalNote: isNote,
      wahaStatus: 'SENT' as const,
      sentAt: new Date().toISOString(),
      sentBy: null,
      conversationId: null,
    };

    setMessages(prev => [...prev, optimisticMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contactId: contact.id,
          content,
          type
        }),
      });

      if (res.ok) {
        const newMsg = await res.json();
        // Replace temp message with real one from server
        setMessages(prev => prev.map(m => m.id === tempId ? newMsg : m));
      } else {
        // Remove optimistic message on failure
        setMessages(prev => prev.filter(m => m.id !== tempId));
      }
    } catch (error) {
      console.error('Error sending message:', error);
      // Remove optimistic message on error
      setMessages(prev => prev.filter(m => m.id !== tempId));
    } finally {
      setLoading(false);
    }
  };

  if (!contact) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 h-full text-gray-400">
        <p>Pilih percakapan dari panel kiri untuk mulai membalas pesan</p>
      </div>
    );
  }

  const displayName = contact.fullName || contact.whatsappNumber;

  return (
    <div className="flex-1 flex flex-col h-full bg-[#E5DDD5]">
      {/* Header */}
      <div className="bg-white border-b px-6 py-3 flex items-center shadow-sm z-10">
        <div className="h-10 w-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold mr-4 shadow-sm">
          {displayName.substring(0, 2).toUpperCase()}
        </div>
        <div>
          <h2 className="font-semibold text-gray-800">{displayName}</h2>
          <p className="text-xs text-gray-500">{contact.whatsappNumber}</p>
        </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 md:p-6"
        style={{ backgroundImage: 'url("https://waha.devlike.pro/img/bg-chat.png")', backgroundSize: 'contain', backgroundBlendMode: 'soft-light' }}
      >
        {messages.length === 0 ? (
          <div className="text-center text-sm text-gray-500 bg-white/80 p-2 rounded-lg max-w-xs mx-auto shadow-sm">
            Belum ada pesan. Mulai percakapan sekarang.
          </div>
        ) : (
          messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))
        )}
      </div>

      {/* Input Area */}
      <div className="bg-[#F0F2F5] px-4 py-3 border-t">
        <form onSubmit={handleSend} className="flex items-center space-x-2">
          
          <button
            type="button"
            onClick={() => setIsNote(!isNote)}
            className={`p-2 rounded-full transition-colors ${
              isNote ? 'bg-yellow-100 text-yellow-600 border border-yellow-300' : 'text-gray-500 hover:bg-gray-200'
            }`}
            title="Tambah Internal Note"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </button>
          
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={loading}
            placeholder={isNote ? "Ketik catatan internal (tidak terkirim ke pelanggan)..." : "Ketik pesan..."}
            className={`flex-1 py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors shadow-sm ${
              isNote ? 'bg-yellow-50 placeholder-yellow-600/50 text-yellow-900 border-yellow-200' : 'bg-white border-transparent'
            }`}
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="p-3 bg-green-500 text-white rounded-full hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm transition-colors"
          >
            {loading ? (
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
              </svg>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
