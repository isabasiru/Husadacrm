'use client';

import { format } from 'date-fns';
import { id } from 'date-fns/locale';

interface User {
  id: string;
  fullName: string;
}

interface Message {
  id: string;
  content: string;
  direction: 'INBOUND' | 'OUTBOUND';
  type: 'TEXT' | 'IMAGE' | 'DOCUMENT' | 'AUDIO' | 'INTERNAL_NOTE';
  wahaStatus: 'SENT' | 'DELIVERED' | 'READ' | 'FAILED' | null;
  sentAt: string;
  isInternalNote: boolean;
  sentBy?: User | null;
}

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isOutbound = message.direction === 'OUTBOUND';
  const isNote = message.isInternalNote || message.type === 'INTERNAL_NOTE';

  // Waktu format: 14:30
  const timeString = format(new Date(message.sentAt), 'HH:mm', { locale: id });

  return (
    <div className={`flex w-full mb-4 ${isOutbound ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`relative max-w-[75%] px-4 py-2 rounded-lg shadow-sm ${
          isNote
            ? 'bg-yellow-100 border border-yellow-200 text-yellow-900 rounded-tr-none'
            : isOutbound
            ? 'bg-green-100 border border-green-200 text-green-900 rounded-tr-none'
            : 'bg-white border border-gray-200 text-gray-900 rounded-tl-none'
        }`}
      >
        {isOutbound && message.sentBy && !isNote && (
          <div className="text-[10px] font-semibold text-green-700 mb-1 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
            Dibalas oleh: {message.sentBy.fullName}
          </div>
        )}
        
        {isNote && (
          <div className="text-[10px] font-semibold text-yellow-700 mb-1 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            Internal Note
            {message.sentBy && ` (dari ${message.sentBy.fullName})`}
          </div>
        )}

        <div className="text-sm whitespace-pre-wrap break-words">
          {message.content}
        </div>

        <div className={`text-[10px] text-right mt-1 flex items-center justify-end space-x-1 ${
          isNote ? 'text-yellow-600' : isOutbound ? 'text-green-600' : 'text-gray-400'
        }`}>
          <span>{timeString}</span>
          {isOutbound && !isNote && (
            <span>
              {message.wahaStatus === 'SENT' && '✓'}
              {message.wahaStatus === 'DELIVERED' && '✓✓'}
              {message.wahaStatus === 'READ' && (
                <span className="text-blue-500">✓✓</span>
              )}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
