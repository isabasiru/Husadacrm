'use client';

import { formatDistanceToNow } from 'date-fns';
import { id } from 'date-fns/locale';

interface Contact {
  id: string;
  fullName: string | null;
  whatsappNumber: string;
  lastInteractionAt: string | null;
  stageId?: string | null;
}

interface ContactListProps {
  contacts: Contact[];
  selectedContactId: string | null;
  onSelect: (contact: Contact) => void;
  loading?: boolean;
}

export function ContactList({ contacts, selectedContactId, onSelect, loading }: ContactListProps) {
  if (loading) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-white border-r">
        <svg className="animate-spin h-8 w-8 text-green-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-white border-r flex flex-col">
      <div className="p-4 border-b bg-gray-50 flex-shrink-0">
        <h2 className="text-xl font-bold text-gray-800">Inbox</h2>
        <div className="mt-2 relative">
          <input
            type="text"
            placeholder="Cari chat..."
            className="w-full pl-9 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <svg className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {contacts.length === 0 ? (
          <div className="p-4 text-center text-gray-500 text-sm">
            Tidak ada percakapan.
          </div>
        ) : (
          contacts.map((contact) => {
            const displayName = contact.fullName || contact.whatsappNumber;
            const timeAgo = contact.lastInteractionAt 
              ? formatDistanceToNow(new Date(contact.lastInteractionAt), { addSuffix: true, locale: id })
              : '';

            return (
              <div
                key={contact.id}
                onClick={() => onSelect(contact)}
                className={`flex items-center p-4 border-b cursor-pointer transition-colors ${
                  selectedContactId === contact.id ? 'bg-green-50' : 'hover:bg-gray-50'
                }`}
              >
                <div className="h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold mr-4 flex-shrink-0">
                  {displayName.substring(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <h3 className="text-sm font-semibold text-gray-900 truncate pr-2">
                      {displayName}
                    </h3>
                    <span className="text-xs text-gray-500 flex-shrink-0">
                      {timeAgo}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">
                    {contact.whatsappNumber}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
