'use client';

import { useState, useEffect } from 'react';
import { ContactList } from './ContactList';
import { ChatWindow } from './ChatWindow';
import { useSocket } from '@/hooks/use-socket';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function InboxClient({ initialContacts }: { initialContacts: any[] }) {
  const [contacts, setContacts] = useState(initialContacts);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [selectedContact, setSelectedContact] = useState<any | null>(null);
  
  const { onInboxUpdate } = useSocket();

  // Handle incoming new messages at the inbox level to re-order contact list
  useEffect(() => {
    const cleanup = onInboxUpdate((update) => {
      // update = { contactId, conversationId, lastMessage, lastMessageAt }
      setContacts((prev) => {
        const contactIndex = prev.findIndex(c => c.id === update.contactId);
        if (contactIndex === -1) {
          fetch('/api/contacts')
            .then(res => res.json())
            .then(data => setContacts(data));
          return prev;
        }

        // Move to top and update lastInteraction
        const newContacts = [...prev];
        const updatedContact = { ...newContacts[contactIndex], lastInteractionAt: update.lastMessageAt || new Date().toISOString() };
        newContacts.splice(contactIndex, 1);
        newContacts.unshift(updatedContact);
        return newContacts;
      });
    });

    return cleanup;
  }, [onInboxUpdate]);

  return (
    <div className="flex h-[calc(100vh-4rem)] bg-white overflow-hidden">
      <div className="w-1/3 min-w-[300px] max-w-[400px] h-full border-r">
        <ContactList 
          contacts={contacts}
          selectedContactId={selectedContact?.id || null}
          onSelect={setSelectedContact}
        />
      </div>
      <div className="flex-1 h-full">
        <ChatWindow contact={selectedContact} />
      </div>
    </div>
  );
}
