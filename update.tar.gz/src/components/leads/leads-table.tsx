'use client';

import { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { LeadDetailsSlideout } from './lead-details-slideout';

type Stage = { id: string; name: string; color: string };
type Agent = { id: string; fullName: string };
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Contact = any;

interface LeadsTableProps {
  initialContacts: Contact[];
  stages: Stage[];
  agents: Agent[];
}

export function LeadsTableClient({ initialContacts, stages, agents }: LeadsTableProps) {
  const [contacts, setContacts] = useState(initialContacts);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  // Filter contacts based on search term
  const filteredContacts = contacts.filter(c => 
    c.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.whatsappNumber.includes(searchTerm)
  );

  const updateContactInline = async (id: string, field: string, value: string | null) => {
    // Optimistic update
    setContacts(prev => prev.map(c => {
      if (c.id === id) {
        return { ...c, [field]: value };
      }
      return c;
    }));

    try {
      const res = await fetch(`/api/contacts/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [field]: value }),
      });
      if (!res.ok) {
        throw new Error('Update failed');
      }
    } catch (error) {
      console.error(error);
      alert('Gagal mengupdate data.');
      // Revert optimistic update ideally, but skipping for simplicity here
    }
  };

  const handleSavedContact = (updatedContact: Contact) => {
    setContacts(prev => prev.map(c => c.id === updatedContact.id ? { ...c, ...updatedContact } : c));
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header & Controls */}
      <div className="flex items-center justify-between p-6 border-b">
        <h1 className="text-2xl font-bold text-slate-800">Leads Management</h1>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari nama atau nomor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#1A56DB] outline-none"
            />
          </div>
          <button className="flex items-center px-4 py-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-50">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </button>
        </div>
      </div>

      {/* Table Area */}
      <div className="flex-1 overflow-auto p-6">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-200">
              <th className="py-3 font-semibold text-slate-600">Nama Pasien</th>
              <th className="py-3 font-semibold text-slate-600">No. WhatsApp</th>
              <th className="py-3 font-semibold text-slate-600">Status</th>
              <th className="py-3 font-semibold text-slate-600">FR (Agent)</th>
              <th className="py-3 font-semibold text-slate-600">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredContacts.map(contact => (
              <tr key={contact.id} className="hover:bg-slate-50 transition-colors">
                <td className="py-3">
                  <div className="font-medium text-slate-800">{contact.fullName || '-'}</div>
                  {contact.age && <div className="text-xs text-slate-500">{contact.age} thn</div>}
                </td>
                <td className="py-3 text-slate-600">{contact.whatsappNumber}</td>
                <td className="py-3">
                  <select 
                    value={contact.stageId || ''}
                    onChange={(e) => updateContactInline(contact.id, 'stageId', e.target.value || null)}
                    className="border border-slate-200 rounded px-2 py-1 text-sm bg-white focus:ring-1 focus:ring-[#1A56DB] outline-none"
                  >
                    <option value="">Belum ada status</option>
                    {stages.map(stage => (
                      <option key={stage.id} value={stage.id}>{stage.name}</option>
                    ))}
                  </select>
                </td>
                <td className="py-3">
                  <select 
                    value={contact.assignedAgentId || ''}
                    onChange={(e) => updateContactInline(contact.id, 'assignedAgentId', e.target.value || null)}
                    className="border border-slate-200 rounded px-2 py-1 text-sm bg-white focus:ring-1 focus:ring-[#1A56DB] outline-none"
                  >
                    <option value="">Belum di-assign</option>
                    {agents.map(agent => (
                      <option key={agent.id} value={agent.id}>{agent.fullName}</option>
                    ))}
                  </select>
                </td>
                <td className="py-3">
                  <button 
                    onClick={() => setSelectedContact(contact)}
                    className="text-[#1A56DB] hover:underline text-sm font-medium"
                  >
                    Detail
                  </button>
                </td>
              </tr>
            ))}
            {filteredContacts.length === 0 && (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-500">
                  Tidak ada data pasien yang ditemukan.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <LeadDetailsSlideout 
        isOpen={!!selectedContact} 
        onClose={() => setSelectedContact(null)} 
        contact={selectedContact}
        onSaved={handleSavedContact}
      />
    </div>
  );
}
