import { useState } from "react";
import { Search } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Contact, Stage, ContactTag, Tag } from "@prisma/client";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
  conversations?: { lastRepliedBy: { fullName: string } | null }[];
};

export function ChatList({ 
  contacts, 
  selectedId, 
  onSelect 
}: { 
  contacts: ContactWithRelations[],
  selectedId: string | null,
  onSelect: (id: string) => void
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const uniqueStages = Array.from(new Set(contacts.map(c => c.stage?.name).filter(Boolean))) as string[];

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = (contact.fullName || contact.whatsappNumber).toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStage = activeStage ? contact.stage?.name === activeStage : true;
    return matchesSearch && matchesStage;
  });

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <div className="relative mb-3">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search contacts..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-100 rounded-lg outline-none focus:ring-2 focus:ring-[#1A56DB] text-sm"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button 
            onClick={() => setActiveStage(null)}
            className={`text-xs px-3 py-1 rounded-full whitespace-nowrap border transition-colors ${!activeStage ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 hover:bg-slate-50'}`}
          >
            All
          </button>
          {uniqueStages.map(stage => (
            <button
              key={stage}
              onClick={() => setActiveStage(stage)}
              className={`text-xs px-3 py-1 rounded-full whitespace-nowrap border transition-colors ${activeStage === stage ? 'bg-[#1A56DB] text-white border-[#1A56DB]' : 'bg-white text-slate-600 hover:bg-slate-50'}`}
            >
              {stage}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {filteredContacts.length === 0 ? (
          <div className="p-4 text-center text-sm text-slate-500">No contacts found.</div>
        ) : (
          filteredContacts.map(contact => (
            <div 
              key={contact.id}
              onClick={() => onSelect(contact.id)}
              className={`p-4 border-b cursor-pointer hover:bg-slate-50 transition-colors ${selectedId === contact.id ? 'bg-[#EFF6FF] border-l-4 border-l-[#1A56DB]' : ''}`}
            >
              <div className="flex justify-between items-start mb-1">
                <h3 className="font-semibold text-slate-900 truncate pr-2">{contact.fullName || contact.whatsappNumber}</h3>
                <span className="text-xs text-slate-500 whitespace-nowrap">
                  {formatDistanceToNow(new Date(contact.updatedAt), { addSuffix: true })}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-600 truncate flex gap-2 items-center">
                  {contact.stage ? (
                    <span className="text-xs px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-medium">
                      {contact.stage.name}
                    </span>
                  ) : 'No stage'}
                  {contact.conversations?.[0]?.lastRepliedBy && (
                    <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700 rounded border border-blue-100 flex items-center gap-1">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path></svg>
                      {contact.conversations[0].lastRepliedBy.fullName.split(' ')[0]}
                    </span>
                  )}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
