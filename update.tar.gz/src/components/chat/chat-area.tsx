import { Contact, Stage, ContactTag, Tag, Message, MessageTemplate } from "@prisma/client";
import { Send, Paperclip, MoreVertical, Zap } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import io, { Socket } from "socket.io-client";
import { format } from "date-fns";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
  conversations?: { id: string, lastRepliedBy: { fullName: string } | null }[];
};

export function ChatArea({ contact }: { contact: ContactWithRelations }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [showTemplates, setShowTemplates] = useState(false);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    // Fetch messages
    setIsLoading(true);
    Promise.all([
      fetch(`/api/messages?contactId=${contact.id}`).then(res => res.json()),
      fetch('/api/templates').then(res => res.json())
    ])
      .then(([messagesData, templatesData]) => {
        if (Array.isArray(messagesData)) {
          setMessages(messagesData);
        }
        if (Array.isArray(templatesData)) {
          setTemplates(templatesData);
        }
      })
      .finally(() => setIsLoading(false));

    // Connect to socket
    const socket = io({ path: '/api/socketio' });
    socketRef.current = socket;

    socket.on('connect', () => {
      if (contact.conversations?.[0]?.id) {
        socket.emit('join_conversation', contact.conversations[0].id);
      }
    });

    socket.on('new_message', (msg) => {
      setMessages(prev => {
        if (prev.find(m => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
    });

    return () => {
      socket.disconnect();
    };
  }, [contact.id, contact.conversations]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const content = input;
    setInput("");

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contactId: contact.id,
          content: content,
          type: 'TEXT'
        })
      });
      if (res.ok) {
        const newMsg = await res.json();
        setMessages(prev => {
          if (prev.find(m => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
      }
    } catch (error) {
      console.error("Failed to send message", error);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="h-16 border-b bg-white flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center text-slate-600 font-bold">
            {contact.fullName ? contact.fullName.charAt(0).toUpperCase() : '#'}
          </div>
          <div className="ml-3">
            <h2 className="font-semibold text-slate-900">{contact.fullName || contact.whatsappNumber}</h2>
            <p className="text-xs text-slate-500">{contact.whatsappNumber}</p>
          </div>
        </div>
        <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>

      {/* Messages List */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4" ref={scrollRef}>
        {isLoading && (
          <div className="flex justify-center text-slate-400 text-sm">Loading messages...</div>
        )}
        
        {messages.map((msg, i) => {
          const isOutbound = msg.direction === 'OUTBOUND';
          return (
            <div key={msg.id || i} className={`flex ${isOutbound ? 'justify-end' : 'justify-start'}`}>
              <div className={`${isOutbound ? 'bg-[#1A56DB] text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none'} p-3 rounded-lg shadow-sm max-w-[70%]`}>
                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                <div className={`text-[10px] mt-1 flex gap-1 justify-end ${isOutbound ? 'text-blue-200' : 'text-slate-400'}`}>
                  {msg.sentAt && format(new Date(msg.sentAt), 'hh:mm a')}
                  {isOutbound && (
                    <span>
                      {msg.wahaStatus === 'READ' ? '✓✓' : msg.wahaStatus === 'DELIVERED' ? '✓✓' : '✓'}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t shrink-0 relative">
        {showTemplates && (
          <div className="absolute bottom-full left-4 mb-2 w-64 bg-white border shadow-lg rounded-xl overflow-hidden z-10">
            <div className="p-2 bg-slate-50 border-b text-xs font-bold text-slate-500 uppercase">Quick Replies</div>
            <div className="max-h-48 overflow-y-auto">
              {templates.length === 0 ? (
                <div className="p-3 text-sm text-slate-500 text-center">No templates available</div>
              ) : (
                templates.map(tpl => (
                  <button 
                    key={tpl.id}
                    className="w-full text-left p-3 hover:bg-[#EFF6FF] border-b last:border-b-0 transition-colors"
                    onClick={() => {
                      let text = tpl.content;
                      text = text.replace(/{{nama}}/g, contact.fullName?.split(' ')[0] || contact.whatsappNumber);
                      // Add other replacements as needed
                      setInput(text);
                      setShowTemplates(false);
                    }}
                  >
                    <div className="text-sm font-semibold text-slate-800">{tpl.name}</div>
                    <div className="text-xs text-slate-500 truncate mt-1">{tpl.content}</div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
        <div className="flex items-end bg-slate-50 border rounded-xl overflow-hidden p-2">
          <button 
            className={`p-2 transition-colors ${showTemplates ? 'text-[#1A56DB] bg-blue-50 rounded' : 'text-slate-400 hover:text-slate-600'}`}
            onClick={() => setShowTemplates(!showTemplates)}
            title="Quick Replies"
          >
            <Zap className="w-5 h-5" />
          </button>
          <button className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <Paperclip className="w-5 h-5" />
          </button>
          <textarea 
            placeholder="Type your message..." 
            className="flex-1 bg-transparent border-none outline-none resize-none max-h-32 min-h-[40px] px-3 py-2 text-sm text-slate-700"
            rows={1}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          ></textarea>
          <button onClick={handleSend} className="p-2 bg-[#1A56DB] text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
