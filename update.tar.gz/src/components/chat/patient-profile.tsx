import { Contact, Stage, ContactTag, Tag } from "@prisma/client";
import { UserCircle, MapPin, Calendar, Tag as TagIcon, FileText } from "lucide-react";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
};

export function PatientProfile({ contact }: { contact: ContactWithRelations }) {
  return (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b flex flex-col items-center">
        <div className="w-20 h-20 bg-slate-200 rounded-full flex items-center justify-center text-slate-500 font-bold text-2xl mb-4">
          {contact.fullName ? contact.fullName.charAt(0).toUpperCase() : '#'}
        </div>
        <h2 className="font-bold text-lg text-slate-900 text-center">{contact.fullName || 'Unknown Patient'}</h2>
        <p className="text-sm text-slate-500">{contact.whatsappNumber}</p>
        
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          {contact.stage && (
            <span className="px-3 py-1 bg-blue-100 text-[#1A56DB] text-xs font-semibold rounded-full">
              {contact.stage.name}
            </span>
          )}
          {contact.tags.map(ct => (
            <span key={ct.tagId} className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-semibold rounded-full flex items-center">
              <TagIcon className="w-3 h-3 mr-1" />
              {ct.tag.name}
            </span>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-6 flex-1 overflow-y-auto">
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Patient Details</h3>
          <div className="space-y-3">
            <div className="flex items-start">
              <UserCircle className="w-5 h-5 text-slate-400 mr-3 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-slate-900">MRN / ID</p>
                <p className="text-sm text-slate-500">{contact.id.substring(0,8)}...</p>
              </div>
            </div>
            {contact.domicile && (
              <div className="flex items-start">
                <MapPin className="w-5 h-5 text-slate-400 mr-3 mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-slate-900">Address</p>
                  <p className="text-sm text-slate-500">{contact.domicile}</p>
                </div>
              </div>
            )}
            <div className="flex items-start">
              <Calendar className="w-5 h-5 text-slate-400 mr-3 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-slate-900">Added On</p>
                <p className="text-sm text-slate-500">{new Date(contact.createdAt).toLocaleDateString()}</p>
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Internal Notes</h3>
            <button className="text-[#1A56DB] text-xs font-medium hover:underline">Add Note</button>
          </div>
          {contact.notes ? (
            <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg flex items-start">
              <FileText className="w-4 h-4 text-amber-500 mr-2 shrink-0 mt-0.5" />
              <p className="text-sm text-amber-900 whitespace-pre-wrap">{contact.notes}</p>
            </div>
          ) : (
            <p className="text-sm text-slate-500 italic">No internal notes for this patient.</p>
          )}
        </div>
      </div>
    </div>
  );
}
