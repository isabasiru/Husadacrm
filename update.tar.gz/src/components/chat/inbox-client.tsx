"use client";

import { useState } from "react";
import { ChatList } from "./chat-list";
import { ChatArea } from "./chat-area";
import { PatientProfile } from "./patient-profile";
import { Contact, Stage, ContactTag, Tag } from "@prisma/client";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
  conversations?: { id: string, lastRepliedBy: { fullName: string } | null }[];
};

export function InboxClient({ initialContacts }: { initialContacts: ContactWithRelations[] }) {
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  
  const selectedContact = initialContacts.find(c => c.id === selectedContactId) || null;

  return (
    <div className="flex flex-1 w-full h-full overflow-hidden">
      {/* Column 1: Chat List */}
      <div className="w-1/3 min-w-[300px] max-w-[400px] border-r flex flex-col bg-white">
        <ChatList 
          contacts={initialContacts} 
          selectedId={selectedContactId} 
          onSelect={setSelectedContactId} 
        />
      </div>

      {/* Column 2: Chat Area */}
      <div className="flex-1 flex flex-col bg-[#F0F2F5]">
        {selectedContact ? (
          <ChatArea contact={selectedContact} />
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500">
            Select a conversation to start messaging
          </div>
        )}
      </div>

      {/* Column 3: Patient Profile */}
      <div className="w-1/4 min-w-[250px] max-w-[350px] border-l bg-white overflow-y-auto">
        {selectedContact && <PatientProfile contact={selectedContact} />}
      </div>
    </div>
  );
}
