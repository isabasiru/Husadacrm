'use client';

import Link from "next/link";
import { useRouter } from "next/navigation";
import { MessageSquare, Users, LayoutDashboard, Settings, LogOut, Hospital, Megaphone } from "lucide-react";

export function Sidebar({ role = 'AGENT' }: { role?: string }) {
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (err) {
      console.error('Logout failed', err);
    }
  };

  const isAdminOrSuper = role === 'ADMIN' || role === 'SUPER_ADMIN';

  return (
    <div className="w-16 md:w-64 border-r bg-white h-screen flex flex-col justify-between">
      <div>
        <div className="h-16 flex items-center justify-center md:justify-start md:px-6 border-b text-[#1A56DB]">
          <Hospital className="w-6 h-6" />
          <span className="ml-3 font-bold hidden md:block">Husada CRM</span>
        </div>
        <nav className="p-2 space-y-1">
          <Link href="/dashboard" className="flex items-center px-2 py-3 rounded hover:bg-slate-100 text-slate-700">
            <MessageSquare className="w-5 h-5 mx-auto md:mx-0" />
            <span className="ml-3 hidden md:block">Inbox</span>
          </Link>
          <Link href="/dashboard/leads" className="flex items-center px-2 py-3 rounded hover:bg-slate-100 text-slate-700">
            <Users className="w-5 h-5 mx-auto md:mx-0" />
            <span className="ml-3 hidden md:block">Leads</span>
          </Link>
          {isAdminOrSuper && (
            <Link href="/dashboard/broadcast" className="flex items-center px-2 py-3 rounded hover:bg-slate-100 text-slate-700">
              <Megaphone className="w-5 h-5 mx-auto md:mx-0" />
              <span className="ml-3 hidden md:block">Broadcast</span>
            </Link>
          )}
          <Link href="/dashboard/kanban" className="flex items-center px-2 py-3 rounded hover:bg-slate-100 text-slate-700">
            <LayoutDashboard className="w-5 h-5 mx-auto md:mx-0" />
            <span className="ml-3 hidden md:block">Kanban</span>
          </Link>
        </nav>
      </div>
      <div className="p-2 border-t">
        {isAdminOrSuper && (
          <Link href="/dashboard/settings" className="flex items-center px-2 py-3 rounded hover:bg-slate-100 text-slate-700">
            <Settings className="w-5 h-5 mx-auto md:mx-0" />
            <span className="ml-3 hidden md:block">Settings</span>
          </Link>
        )}
        <button 
          onClick={handleLogout}
          className="w-full flex items-center px-2 py-3 rounded hover:bg-red-50 text-red-600 mt-1"
        >
          <LogOut className="w-5 h-5 mx-auto md:mx-0" />
          <span className="ml-3 hidden md:block">Logout</span>
        </button>
      </div>
    </div>
  );
}
