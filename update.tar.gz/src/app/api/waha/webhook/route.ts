import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
// Socket.io is available via global.__socketIO from custom server.js
// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare const global: { __socketIO?: any } & typeof globalThis;

export async function POST(request: Request) {
  try {
    const payload = await request.json();
    console.log('Incoming Waha Webhook:', JSON.stringify(payload, null, 2));

    // Waha structure generally looks like:
    // { event: 'message', payload: { id, from, to, body, type, ack, timestamp, ... } }
    
    // We only process message incoming events here
    if (payload?.event === 'message') {
      const msg = payload.payload;
      if (!msg) return NextResponse.json({ success: true });

      // Clean the phone number (assuming 'from' looks like '62812345678@c.us' or '...text@lid')
      let fromNumber = msg.from;
      if (fromNumber?.endsWith('@c.us')) fromNumber = fromNumber.split('@')[0];
      
      let toNumber = msg.to;
      if (toNumber?.endsWith('@c.us')) toNumber = toNumber.split('@')[0];

      const isFromMe = msg.fromMe; // Boolean
      const contactNumber = isFromMe ? toNumber : fromNumber;

      if (!contactNumber) return NextResponse.json({ success: true });

      // 1. Find or Create Contact
      // Check if contact exists
      let contact = await prisma.contact.findUnique({
        where: { whatsappNumber: contactNumber }
      });

      if (!contact) {
        // If it's a completely new contact, create it and assign to default stage
        const defaultStage = await prisma.stage.findFirst({ where: { isDefault: true } });
        contact = await prisma.contact.create({
          data: {
            whatsappNumber: contactNumber,
            fullName: msg._data?.notifyName || contactNumber,
            stageId: defaultStage?.id,
            source: 'whatsapp_webhook',
          }
        });
      }

      // 2. Find or Create Conversation (Status = OPEN)
      let conversation = await prisma.conversation.findFirst({
        where: { contactId: contact.id, status: 'OPEN' }
      });

      if (!conversation) {
        conversation = await prisma.conversation.create({
          data: {
            contactId: contact.id,
            wahaSession: 'default', // Ideally from payload if multiple sessions
          }
        });
      }

      // 3. Save Message
      const wahaType = msg.type || msg._data?.type || 'chat';
      let messageType: 'TEXT' | 'IMAGE' | 'DOCUMENT' | 'AUDIO' = 'TEXT';
      if (wahaType === 'image') messageType = 'IMAGE';
      else if (wahaType === 'document') messageType = 'DOCUMENT';
      else if (wahaType === 'ptt' || wahaType === 'audio' || wahaType === 'voice') messageType = 'AUDIO';
      
      const savedMessage = await prisma.message.create({
        data: {
          conversationId: conversation.id,
          wahaMessageId: msg.id,
          direction: isFromMe ? 'OUTBOUND' : 'INBOUND',
          type: messageType,
          content: msg.body,
          wahaStatus: msg.ack ? 'DELIVERED' : 'SENT', // simplify logic
          sentAt: new Date(msg.timestamp * 1000), // Waha timestamp is usually seconds
        }
      });

      // Update Conversation's lastMessageAt
      await prisma.conversation.update({
        where: { id: conversation.id },
        data: { lastMessageAt: new Date() }
      });

      // Update Contact's total messages & last interaction
      await prisma.contact.update({
        where: { id: contact.id },
        data: { 
          lastInteractionAt: new Date(),
          totalMessages: { increment: 1 }
        }
      });

      // Socket.io emit to notify frontend in real-time
      const io = global.__socketIO;
      if (io) {
        // Emit to specific conversation room
        io.to(`conversation:${conversation.id}`).emit('new_message', {
          conversationId: conversation.id,
          message: savedMessage,
          contact: contact
        });
        // Also emit globally for inbox list updates
        io.emit('inbox_update', {
          contactId: contact.id,
          conversationId: conversation.id,
          lastMessage: savedMessage.content,
          lastMessageAt: savedMessage.sentAt,
        });
      }

    } else if (payload?.event === 'message.ack') {
      // Handle message status updates (Delivered, Read)
      const ackMsg = payload.payload;
      if (ackMsg?.id?.id) {
        let statusStr = 'SENT';
        if (ackMsg.ack === 2) statusStr = 'DELIVERED';
        if (ackMsg.ack === 3) statusStr = 'READ';

        await prisma.message.updateMany({
          where: { wahaMessageId: ackMsg.id._serialized || ackMsg.id.id },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          data: { wahaStatus: statusStr as any }
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    console.error('Waha webhook error:', error);
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}
