import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const whereClause: Prisma.ContactWhereInput = {};
    if (session.role === 'AGENT') {
      whereClause.assignedAgentId = session.userId;
    }

    const contacts = await prisma.contact.findMany({
      where: whereClause,
      orderBy: { lastInteractionAt: 'desc' },
      select: {
        id: true,
        fullName: true,
        whatsappNumber: true,
        lastInteractionAt: true,
        stageId: true,
        conversations: {
          where: { status: 'OPEN' },
          take: 1,
          select: {
            lastRepliedBy: {
              select: { fullName: true }
            }
          }
        }
      },
      take: 50,
    });
    return NextResponse.json(contacts);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    return NextResponse.json({ error: 'Failed to fetch contacts' }, { status: 500 });
  }
}
