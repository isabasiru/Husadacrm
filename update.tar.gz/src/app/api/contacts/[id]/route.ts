import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const {
      fullName,
      whatsappNumber,
      age,
      domicile,
      chiefComplaint,
      initialQuestion,
      medicalSupportData,
      notes,
      stageId,
      assignedAgentId
    } = body;

    // Check if contact exists
    const existingContact = await prisma.contact.findUnique({
      where: { id }
    });

    if (!existingContact) {
      return NextResponse.json(
        { error: 'Contact not found' },
        { status: 404 }
      );
    }

    // Build update data, only including fields that are provided
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const updateData: any = {};
    if (fullName !== undefined) updateData.fullName = fullName;
    if (whatsappNumber !== undefined) updateData.whatsappNumber = whatsappNumber;
    if (age !== undefined) updateData.age = age ? parseInt(age, 10) : null;
    if (domicile !== undefined) updateData.domicile = domicile;
    if (chiefComplaint !== undefined) updateData.chiefComplaint = chiefComplaint;
    if (initialQuestion !== undefined) updateData.initialQuestion = initialQuestion;
    if (medicalSupportData !== undefined) updateData.medicalSupportData = medicalSupportData;
    if (notes !== undefined) updateData.notes = notes;
    if (stageId !== undefined) updateData.stageId = stageId === 'null' ? null : stageId;
    if (assignedAgentId !== undefined) updateData.assignedAgentId = assignedAgentId === 'null' ? null : assignedAgentId;

    const updatedContact = await prisma.contact.update({
      where: { id },
      data: updateData,
      include: {
        stage: true,
        assignedAgent: true
      }
    });

    return NextResponse.json({
      success: true,
      contact: updatedContact
    });
  } catch (error) {
    console.error('Error updating contact:', error);
    return NextResponse.json(
      { error: 'Failed to update contact' },
      { status: 500 }
    );
  }
}
