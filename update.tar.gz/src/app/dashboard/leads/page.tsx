import prisma from '@/lib/prisma';
import { LeadsTableClient } from '@/components/leads/leads-table';

export const dynamic = 'force-dynamic';

export default async function LeadsPage() {
  // Fetch initial contacts
  const contacts = await prisma.contact.findMany({
    orderBy: { updatedAt: 'desc' },
    include: {
      stage: true,
      assignedAgent: true,
      tags: { include: { tag: true } }
    }
  });

  // Fetch stages for the dropdown
  const stages = await prisma.stage.findMany({
    orderBy: { orderIndex: 'asc' },
    select: { id: true, name: true, color: true }
  });

  // Fetch agents for the dropdown (role AGENT or ADMIN)
  const agents = await prisma.user.findMany({
    where: {
      isActive: true,
      role: { in: ['AGENT', 'ADMIN', 'SUPER_ADMIN'] }
    },
    select: { id: true, fullName: true },
    orderBy: { fullName: 'asc' }
  });

  return (
    <div className="flex-1 overflow-hidden">
      <LeadsTableClient 
        initialContacts={contacts} 
        stages={stages} 
        agents={agents} 
      />
    </div>
  );
}
