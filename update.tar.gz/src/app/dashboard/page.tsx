import prisma from "@/lib/prisma"
import { InboxClient } from "@/components/chat/inbox-client"

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  // Fetch initial contacts
  const contacts = await prisma.contact.findMany({
    take: 50,
    orderBy: { updatedAt: 'desc' },
    include: {
      stage: true,
      tags: { include: { tag: true } }
    }
  });

  return (
    <div className="flex flex-1 overflow-hidden h-full">
      <InboxClient initialContacts={contacts} />
    </div>
  )
}
