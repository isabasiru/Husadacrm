import prisma from '@/lib/prisma';
import { InboxClient } from '@/components/inbox/InboxClient';
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Inbox - Husada CRM',
};

export const dynamic = 'force-dynamic';

export default async function InboxPage() {
  // Ambil daftar kontak di sisi server untuk initial load
  const initialContacts = await prisma.contact.findMany({
    orderBy: { lastInteractionAt: 'desc' },
    select: {
      id: true,
      fullName: true,
      whatsappNumber: true,
      lastInteractionAt: true,
      stageId: true,
    },
    take: 50, // Limit initial load for performance
  });

  return (
    <div className="w-full h-full -m-4 md:-m-6 lg:-m-8">
      {/* We use negative margins to make the inbox take full width/height of the content area */}
      <InboxClient initialContacts={JSON.parse(JSON.stringify(initialContacts))} />
    </div>
  );
}
