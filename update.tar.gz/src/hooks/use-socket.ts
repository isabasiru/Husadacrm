'use client';

import { useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

let globalSocket: Socket | null = null;

function getSocket(): Socket {
  if (!globalSocket) {
    globalSocket = io({
      path: '/api/socketio',
      transports: ['websocket', 'polling'],
    });
  }
  return globalSocket;
}

export function useSocket() {
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    socketRef.current = getSocket();

    return () => {
      // Don't disconnect on unmount — keep the global socket alive
    };
  }, []);

  const joinConversation = useCallback((conversationId: string) => {
    socketRef.current?.emit('join_conversation', conversationId);
  }, []);

  const leaveConversation = useCallback((conversationId: string) => {
    socketRef.current?.emit('leave_conversation', conversationId);
  }, []);

  const joinAgentRoom = useCallback((agentId: string) => {
    socketRef.current?.emit('join_agent_room', agentId);
  }, []);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onNewMessage = useCallback((callback: (data: any) => void) => {
    socketRef.current?.on('new_message', callback);
    return () => {
      socketRef.current?.off('new_message', callback);
    };
  }, []);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onInboxUpdate = useCallback((callback: (data: any) => void) => {
    socketRef.current?.on('inbox_update', callback);
    return () => {
      socketRef.current?.off('inbox_update', callback);
    };
  }, []);

  return {
    socket: socketRef.current,
    joinConversation,
    leaveConversation,
    joinAgentRoom,
    onNewMessage,
    onInboxUpdate,
  };
}
