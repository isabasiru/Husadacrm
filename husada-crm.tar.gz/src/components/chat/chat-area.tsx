import { Contact, Stage, ContactTag, Tag, Message, MessageTemplate, User } from "@prisma/client";
import { Send, Paperclip, MoreVertical, Zap } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import io, { Socket } from "socket.io-client";
import { format } from "date-fns";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
  conversations?: { id: string, lastRepliedById: string | null, lastRepliedBy: { fullName: string } | null }[];
};

type MessageWithRelations = Message & {
  sentBy?: { id: string; fullName: string } | null;
};

export function ChatArea({ 
  contact, 
  currentAgentName = "Agent",
  onContactUpdated
}: { 
  contact: ContactWithRelations,
  currentAgentName?: string,
  onContactUpdated?: (contact: Partial<ContactWithRelations>) => void
}) {
  const [messages, setMessages] = useState<MessageWithRelations[]>([]);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [showTemplates, setShowTemplates] = useState(false);
  const [input, setInput] = useState("");
  const [isNote, setIsNote] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [agents, setAgents] = useState<User[]>([]);
  const [assignedAgentId, setAssignedAgentId] = useState<string | null>(contact.assignedAgentId);

  const scrollRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);

  // Load agents and messages
  useEffect(() => {
    // Fetch agents list
    fetch('/api/agents')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setAgents(data);
        }
      })
      .catch(err => console.error("Failed to load agents", err));

    // Fetch messages & templates
    setIsLoading(true);
    Promise.all([
      fetch(`/api/messages?contactId=${contact.id}`).then(res => res.json()),
      fetch('/api/templates').then(res => res.json())
    ])
      .then(([messagesData, templatesData]) => {
        if (Array.isArray(messagesData)) {
          setMessages(messagesData);
        }
        if (Array.isArray(templatesData)) {
          setTemplates(templatesData);
        }
      })
      .finally(() => setIsLoading(false));

    // Connect to socket
    const socket = io({ path: '/api/socketio' });
    socketRef.current = socket;

    socket.on('connect', () => {
      if (contact.conversations?.[0]?.id) {
        socket.emit('join_conversation', contact.conversations[0].id);
      }
    });

    socket.on('new_message', (data) => {
      if (data && data.message) {
        const msg = data.message;
        setMessages(prev => {
          if (prev.find(m => m.id === msg.id)) return prev;
          return [...prev, msg];
        });
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [contact.id, contact.conversations]);

  // Update assignedAgentId when contact changes
  useEffect(() => {
    setAssignedAgentId(contact.assignedAgentId);
  }, [contact.assignedAgentId, contact.id]);

  // Scroll to bottom when messages list updates
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const content = input;
    const type = isNote ? 'NOTE' : 'TEXT';
    setInput("");

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contactId: contact.id,
          content: content,
          type: type
        })
      });
      if (res.ok) {
        const newMsg = await res.json();
        setMessages(prev => {
          if (prev.find(m => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
        
        // Notify parent list of the update
        if (onContactUpdated) {
          onContactUpdated({
            id: contact.id,
            updatedAt: new Date(),
            lastInteractionAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error("Failed to send message", error);
    }
  };

  const handleAssignChange = async (newAgentId: string) => {
    try {
      const res = await fetch(`/api/contacts/${contact.id}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId: newAgentId })
      });
      if (res.ok) {
        const data = await res.json();
        setAssignedAgentId(newAgentId);
        if (onContactUpdated) {
          onContactUpdated(data.contact);
        }
      }
    } catch (err) {
      console.error("Failed to reassign agent", err);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#F0F2F5]">
      {/* Header with Assignment Controls */}
      <div className="h-16 border-b bg-white flex items-center justify-between px-6 shrink-0 shadow-sm z-10">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center text-slate-600 font-bold">
            {contact.fullName ? contact.fullName.charAt(0).toUpperCase() : '#'}
          </div>
          <div className="ml-3">
            <h2 className="font-semibold text-slate-900 text-sm">{contact.fullName || contact.whatsappNumber}</h2>
            <p className="text-xs text-slate-500">{contact.whatsappNumber}</p>
          </div>
        </div>

        {/* Assignment Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
            <span className="font-semibold text-slate-600">Delegasi:</span>
            <select
              value={assignedAgentId || ''}
              onChange={(e) => handleAssignChange(e.target.value)}
              className="bg-transparent border-none outline-none font-bold text-slate-800 cursor-pointer text-xs"
            >
              <option value="">Belum Ditugaskan</option>
              {agents.map(agent => (
                <option key={agent.id} value={agent.id}>
                  {agent.fullName} ({agent.role})
                </option>
              ))}
            </select>
          </div>
          <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages List Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4" ref={scrollRef}>
        {isLoading && (
          <div className="flex justify-center text-slate-400 text-sm">Memuat pesan...</div>
        )}
        
        {messages.map((msg, i) => {
          const isOutbound = msg.direction === 'OUTBOUND';
          const isInternalNote = msg.isInternalNote || msg.type === 'INTERNAL_NOTE';
          
          return (
            <div key={msg.id || i} className={`flex ${isInternalNote ? 'justify-center my-3' : isOutbound ? 'justify-end' : 'justify-start'}`}>
              {isInternalNote ? (
                // Yellow sticky internal memo bubble style
                <div className="bg-amber-50 border border-amber-200 text-amber-900 px-4 py-2.5 rounded-2xl shadow-sm max-w-[85%] text-xs flex flex-col gap-1">
                  <div className="flex items-center justify-between gap-6 font-bold text-amber-800 border-b border-amber-100 pb-1 mb-1">
                    <span>📌 Catatan Internal</span>
                    {msg.sentBy && (
                      <span className="text-[10px] bg-amber-100/80 px-1.5 py-0.5 rounded">
                        Oleh: {msg.sentBy.fullName}
                      </span>
                    )}
                  </div>
                  <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                  <div className="text-[9px] text-amber-500 text-right">
                    {msg.sentAt && format(new Date(msg.sentAt), 'hh:mm a')}
                  </div>
                </div>
              ) : (
                // Regular WhatsApp Message Bubble
                <div className={`${isOutbound ? 'bg-[#1A56DB] text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none'} p-3 rounded-2xl shadow-sm max-w-[70%] flex flex-col gap-0.5`}>
                  {/* Outbound Agent tag for Collaboration */}
                  {isOutbound && msg.sentBy && (
                    <div className="text-[9px] text-blue-200 font-extrabold pb-0.5">
                      {msg.sentBy.fullName}
                    </div>
                  )}
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                  <div className={`text-[9px] mt-1 flex gap-1 justify-end items-center ${isOutbound ? 'text-blue-200' : 'text-slate-400'}`}>
                    {msg.sentAt && format(new Date(msg.sentAt), 'hh:mm a')}
                    {isOutbound && (
                      <span className="font-bold">
                        {msg.wahaStatus === 'READ' ? '✓✓' : msg.wahaStatus === 'DELIVERED' ? '✓✓' : '✓'}
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Reply vs Internal Note Mode Selector */}
      <div className="flex border-t border-slate-200 bg-slate-50 px-4 text-xs select-none shadow-inner shrink-0">
        <button 
          onClick={() => setIsNote(false)}
          className={`py-2.5 px-4 border-b-2 font-bold transition-all ${
            !isNote 
              ? 'border-[#1A56DB] text-[#1A56DB]' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          💬 Balas Pasien (WhatsApp)
        </button>
        <button 
          onClick={() => setIsNote(true)}
          className={`py-2.5 px-4 border-b-2 font-bold transition-all ${
            isNote 
              ? 'border-amber-500 text-amber-700 bg-amber-50/50' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          📌 Catatan Internal (Klinik)
        </button>
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-slate-200 shrink-0 relative shadow-sm">
        {showTemplates && (
          <div className="absolute bottom-full left-4 mb-2 w-72 bg-white border shadow-2xl rounded-2xl overflow-hidden z-20 animate-in fade-in slide-in-from-bottom-2 duration-150">
            <div className="p-3 bg-slate-50 border-b text-[10px] font-bold text-slate-500 uppercase tracking-wider">Templat Pesan</div>
            <div className="max-h-56 overflow-y-auto">
              {templates.length === 0 ? (
                <div className="p-4 text-sm text-slate-500 text-center">Belum ada templat</div>
              ) : (
                templates.map(tpl => (
                  <button 
                    key={tpl.id}
                    className="w-full text-left p-3.5 hover:bg-[#EFF6FF] border-b border-slate-100 last:border-b-0 transition-colors"
                    onClick={() => {
                      let text = tpl.content;
                      text = text.replace(/{{nama}}/g, contact.fullName?.split(' ')[0] || contact.whatsappNumber);
                      text = text.replace(/{{agent_name}}/g, currentAgentName);
                      setInput(text);
                      setShowTemplates(false);
                    }}
                  >
                    <div className="text-xs font-bold text-slate-800">{tpl.name}</div>
                    <div className="text-[11px] text-slate-400 truncate mt-1">{tpl.content}</div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
        <div className={`flex items-end border rounded-2xl overflow-hidden p-2 transition-all ${
          isNote 
            ? 'bg-amber-50/20 border-amber-200 focus-within:border-amber-400 focus-within:ring-1 focus-within:ring-amber-400' 
            : 'bg-slate-50 border-slate-200 focus-within:border-[#1A56DB] focus-within:ring-1 focus-within:ring-[#1A56DB]'
        }`}>
          <button 
            className={`p-2 transition-colors rounded-lg ${
              showTemplates 
                ? 'text-[#1A56DB] bg-blue-50' 
                : isNote 
                  ? 'text-amber-600 hover:bg-amber-50' 
                  : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
            }`}
            onClick={() => setShowTemplates(!showTemplates)}
            title="Templat Balasan"
          >
            <Zap className="w-5 h-5" />
          </button>
          <button className={`p-2 transition-colors rounded-lg ${isNote ? 'text-amber-600 hover:bg-amber-50' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}>
            <Paperclip className="w-5 h-5" />
          </button>
          <textarea 
            placeholder={isNote ? "Ketik catatan internal..." : "Ketik pesan balasan..."}
            className="flex-1 bg-transparent border-none outline-none resize-none max-h-32 min-h-[40px] px-3 py-2 text-sm text-slate-700 placeholder:text-slate-400"
            rows={1}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          ></textarea>
          <button 
            onClick={handleSend} 
            className={`p-2.5 rounded-xl transition-all shadow-sm ${
              isNote 
                ? 'bg-amber-500 hover:bg-amber-600 text-white' 
                : 'bg-[#1A56DB] hover:bg-blue-700 text-white'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
