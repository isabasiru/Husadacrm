import { useState } from "react";
import { Search, AlertCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { id } from "date-fns/locale";
import { Contact, Stage, ContactTag, Tag } from "@prisma/client";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
  conversations?: { id: string, lastRepliedById: string | null, lastRepliedBy: { fullName: string } | null }[];
  slaWarning?: boolean;
};

export function ChatList({ 
  contacts, 
  selectedId, 
  onSelect,
  stages = []
}: { 
  contacts: ContactWithRelations[],
  selectedId: string | null,
  onSelect: (id: string) => void,
  stages: Stage[]
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = (contact.fullName || contact.whatsappNumber).toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStage = activeStage ? contact.stage?.name === activeStage : true;
    return matchesSearch && matchesStage;
  });

  return (
    <div className="flex flex-col h-full bg-white select-none">
      {/* Search & Filter Header */}
      <div className="p-4 border-b">
        <div className="relative mb-3">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Cari kontak..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-[#1A56DB] text-sm text-slate-700"
          />
        </div>
        
        {/* Stage Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar scroll-smooth">
          <button 
            onClick={() => setActiveStage(null)}
            className={`text-xs px-3.5 py-1.5 rounded-full whitespace-nowrap border transition-all ${
              !activeStage 
                ? 'bg-slate-900 text-white border-slate-900 font-semibold' 
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            Semua
          </button>
          {stages.map(stage => (
            <button
              key={stage.id}
              onClick={() => setActiveStage(stage.name)}
              className={`text-xs px-3.5 py-1.5 rounded-full whitespace-nowrap border transition-all ${
                activeStage === stage.name 
                  ? 'text-white font-semibold' 
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
              style={
                activeStage === stage.name 
                  ? { backgroundColor: stage.color, borderColor: stage.color } 
                  : undefined
              }
            >
              {stage.name}
            </button>
          ))}
        </div>
      </div>

      {/* Contacts List */}
      <div className="flex-1 overflow-y-auto">
        {filteredContacts.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-400">Kontak tidak ditemukan.</div>
        ) : (
          filteredContacts.map(contact => {
            const hasSlaWarning = contact.slaWarning;
            return (
              <div 
                key={contact.id}
                onClick={() => onSelect(contact.id)}
                className={`p-4 border-b cursor-pointer hover:bg-slate-50/80 transition-all flex flex-col gap-1.5 relative ${
                  selectedId === contact.id ? 'bg-blue-50/70 border-l-4 border-l-[#1A56DB]' : ''
                }`}
              >
                {/* Contact Name & Last Interaction Time */}
                <div className="flex justify-between items-start">
                  <h3 className="font-semibold text-slate-900 truncate max-w-[160px] text-sm">
                    {contact.fullName || contact.whatsappNumber}
                  </h3>
                  <span className="text-[10px] text-slate-400 whitespace-nowrap">
                    {contact.lastInteractionAt 
                      ? formatDistanceToNow(new Date(contact.lastInteractionAt), { addSuffix: true, locale: id })
                      : formatDistanceToNow(new Date(contact.updatedAt), { addSuffix: true, locale: id })
                    }
                  </span>
                </div>

                {/* Sub-details (Stage, Last Reply agent, and SLA Alert) */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 flex-wrap max-w-[80%]">
                    {contact.stage && (
                      <span 
                        className="text-[10px] px-2 py-0.5 rounded font-semibold"
                        style={{ backgroundColor: `${contact.stage.color}15`, color: contact.stage.color }}
                      >
                        {contact.stage.name}
                      </span>
                    )}

                    {/* Attribution Tag */}
                    {contact.conversations?.[0]?.lastRepliedBy ? (
                      <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-600 rounded border border-slate-200">
                        Oleh: {contact.conversations[0].lastRepliedBy.fullName.split(' ')[0]}
                      </span>
                    ) : (
                      <span className="text-[10px] px-2 py-0.5 bg-red-50 text-red-600 rounded border border-red-100 font-semibold animate-pulse">
                        Butuh Balasan
                      </span>
                    )}
                  </div>

                  {/* Glowing SLA Alarm Badge */}
                  {hasSlaWarning && (
                    <div className="flex items-center gap-0.5 bg-red-600 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full animate-pulse shadow-md">
                      <AlertCircle className="w-2.5 h-2.5" />
                      <span>SLA</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
