"use client";

import { useState, useEffect, useCallback } from "react";
import { ChatList } from "./chat-list";
import { ChatArea } from "./chat-area";
import { PatientProfile } from "./patient-profile";
import { Contact, Stage, ContactTag, Tag } from "@prisma/client";
import { useSocket } from "@/hooks/use-socket";

type ContactWithRelations = Contact & {
  stage: Stage | null;
  tags: (ContactTag & { tag: Tag })[];
  conversations?: { id: string, lastRepliedById: string | null, lastRepliedBy: { fullName: string } | null }[];
  slaWarning?: boolean;
};

const playAlertSound = () => {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5 note
    gainNode.gain.setValueAtTime(0.05, audioCtx.currentTime);
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.15);
    
    setTimeout(() => {
      const osc2 = audioCtx.createOscillator();
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      osc2.connect(gainNode);
      osc2.start();
      osc2.stop(audioCtx.currentTime + 0.25);
    }, 150);
  } catch {
    console.warn("Audio chime play blocked by autoplay settings");
  }
};

export function InboxClient({ 
  initialContacts,
  currentAgentName = "Agent",
  stages = [],
  currentUser = { id: "", role: "AGENT" }
}: { 
  initialContacts: ContactWithRelations[],
  currentAgentName?: string,
  stages: Stage[],
  currentUser?: { id: string, role: string }
}) {
  const [contacts, setContacts] = useState<ContactWithRelations[]>(initialContacts);
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const { socket } = useSocket();

  const selectedContact = contacts.find(c => c.id === selectedContactId) || null;

  // Request notification permissions on mount
  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission !== "granted" && Notification.permission !== "denied") {
        Notification.requestPermission();
      }
    }
  }, []);

  const showSlaNotification = useCallback((patientName: string) => {
    playAlertSound();
    
    // Web notifications
    if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
      new Notification("SLA Warning - Husada CRM", {
        body: `Pasien ${patientName} belum dibalas lebih dari 5 menit!`,
        icon: "/favicon.ico"
      });
    }
    
    // UI Toast
    setToastMessage(`Peringatan SLA: ${patientName} belum dibalas > 5 menit!`);
    setTimeout(() => setToastMessage(null), 5000);
  }, []);

  // 1. Real-time updates & Handovers (Socket.io)
  useEffect(() => {
    if (!socket) return;

    // Handles incoming/outgoing message listing updates
    const handleInboxUpdate = async (data: { contactId: string, lastMessage: string, lastMessageAt: string, senderName?: string }) => {
      setContacts(prev => {
        const existingIndex = prev.findIndex(c => c.id === data.contactId);
        
        if (existingIndex > -1) {
          const updated = [...prev];
          // Update lastReplyBy if we have senderName
          const conversations = updated[existingIndex].conversations ? [...updated[existingIndex].conversations!] : [];
          if (conversations[0]) {
            conversations[0] = {
              ...conversations[0],
              lastRepliedById: data.senderName ? "agent" : null,
              lastRepliedBy: data.senderName ? { fullName: data.senderName } : null
            };
          }

          updated[existingIndex] = {
            ...updated[existingIndex],
            conversations,
            lastInteractionAt: new Date(data.lastMessageAt),
            updatedAt: new Date(data.lastMessageAt),
          };

          // Re-sort list so active contact pops to top
          return updated.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
        } else {
          // If the contact is new or not in the cached 50 contacts, fetch it
          fetch(`/api/contacts/${data.contactId}`)
            .then(res => res.json())
            .then(newContact => {
              if (newContact && newContact.id) {
                setContacts(current => {
                  if (current.some(c => c.id === newContact.id)) return current;
                  return [newContact, ...current].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
                });
              }
            })
            .catch(err => console.error("Failed to fetch new contact:", err));
          return prev;
        }
      });
    };

    // Handles live escalation/re-assignment
    const handleContactAssigned = (data: { contactId: string, fromAgentId: string | null, toAgentId: string, assignedTo: string, assignedBy: string, contact: ContactWithRelations }) => {
      // Role checks for security and access layout
      if (currentUser.role === "AGENT") {
        if (data.toAgentId !== currentUser.id) {
          // If assigned to someone else, remove it from our sidebar list
          setContacts(prev => prev.filter(c => c.id !== data.contactId));
          if (selectedContactId === data.contactId) {
            setSelectedContactId(null);
            setToastMessage(`Obrolan ini telah dipindahkan ke agen ${data.assignedTo}`);
            setTimeout(() => setToastMessage(null), 5000);
          }
        } else {
          // If assigned to us, add it and toast alert
          setContacts(prev => {
            if (prev.some(c => c.id === data.contactId)) return prev;
            return [data.contact, ...prev];
          });
          playAlertSound();
          setToastMessage(`Pasien ${data.contact.fullName || data.contact.whatsappNumber} ditugaskan kepada Anda oleh ${data.assignedBy}!`);
          setTimeout(() => setToastMessage(null), 5000);
        }
      } else {
        // ADMIN / SUPER_ADMIN see everything, just update the assignedAgentId in the local state
        setContacts(prev => prev.map(c => {
          if (c.id === data.contactId) {
            return {
              ...c,
              assignedAgentId: data.toAgentId
            };
          }
          return c;
        }));
        setToastMessage(`Pasien ${data.contact.fullName || data.contact.whatsappNumber} dipindahkan ke ${data.assignedTo}`);
        setTimeout(() => setToastMessage(null), 4000);
      }
    };

    socket.on("inbox_update", handleInboxUpdate);
    socket.on("contact_assigned", handleContactAssigned);

    return () => {
      socket.off("inbox_update", handleInboxUpdate);
      socket.off("contact_assigned", handleContactAssigned);
    };
  }, [socket, currentUser, selectedContactId]);

  // 2. SLA Background Timer Alert (5 mins)
  useEffect(() => {
    const runSlaChecks = () => {
      const now = new Date().getTime();
      setContacts(prev => {
        let changed = false;
        const updated = prev.map(c => {
          const activeConv = c.conversations?.[0];
          // Check if conversation is OPEN and lastRepliedById is null (waiting for response from agent)
          const isPendingAgentResponse = activeConv && activeConv.lastRepliedById === null;
          const waitTime = c.lastInteractionAt ? now - new Date(c.lastInteractionAt).getTime() : 0;
          const isViolatingSLA = isPendingAgentResponse && waitTime > 5 * 60 * 1000; // 5 mins

          if (!!c.slaWarning !== !!isViolatingSLA) {
            changed = true;
            if (isViolatingSLA) {
              showSlaNotification(c.fullName || c.whatsappNumber);
            }
            return { ...c, slaWarning: isViolatingSLA };
          }
          return c;
        });
        return changed ? updated : prev;
      });
    };

    const interval = setInterval(runSlaChecks, 30000); // every 30s
    runSlaChecks();

    return () => clearInterval(interval);
  }, [contacts, showSlaNotification]);

  return (
    <div className="flex flex-1 w-full h-full overflow-hidden relative">
      {/* Toast Alert Popups */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl z-50 flex items-center gap-2 border border-slate-700 animate-bounce">
          <span className="text-sm font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Column 1: Chat List */}
      <div className="w-1/3 min-w-[300px] max-w-[400px] border-r flex flex-col bg-white">
        <ChatList 
          contacts={contacts} 
          selectedId={selectedContactId} 
          onSelect={setSelectedContactId}
          stages={stages}
        />
      </div>

      {/* Column 2: Chat Area */}
      <div className="flex-1 flex flex-col bg-[#F0F2F5]">
        {selectedContact ? (
          <ChatArea 
            contact={selectedContact} 
            currentAgentName={currentAgentName} 
            onContactUpdated={(updated) => {
              setContacts(prev => prev.map(c => c.id === updated.id ? { ...c, ...updated } : c));
            }}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500">
            Select a conversation to start messaging
          </div>
        )}
      </div>

      {/* Column 3: Patient Profile */}
      <div className="w-1/4 min-w-[250px] max-w-[350px] border-l bg-white overflow-y-auto">
        {selectedContact && <PatientProfile contact={selectedContact} />}
      </div>
    </div>
  );
}
